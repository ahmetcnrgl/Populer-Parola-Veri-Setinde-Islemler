import os
import shutil

# Klasör yolları
unprocessed_folder = 'Unprocessed-Passwords'
processed_folder = 'Processed'
index_folder = 'Index'

# "Index" klasöründeki alt klasörlerin adları
index_subfolders = list('abcdefghijklmnopqrstuvwxyz0123456789@')

# Gerekli klasörleri oluşturma
if not os.path.exists(processed_folder):
    os.makedirs(processed_folder)

if not os.path.exists(index_folder):
    os.makedirs(index_folder)

# "Index" klasörünün içinde alt klasörleri oluşturma
for subfolder in index_subfolders:
    subfolder_path = os.path.join(index_folder, subfolder)
    if not os.path.exists(subfolder_path):
        os.makedirs(subfolder_path)

# "Unprocessed-Passwords" klasöründeki dosyaları işleme
for filename in os.listdir(unprocessed_folder):
    file_path = os.path.join(unprocessed_folder, filename)
    if os.path.isfile(file_path):
        with open(file_path, 'r') as file:
            for line in file:
                password = line.strip()
                if password:
                    first_char = password[0].lower()
                    # Eğer ilk karakter belirtilen karakterler arasında değilse 'others' klasörüne koy
                    if first_char not in index_subfolders:
                        first_char = 'others'
                    dest_folder = os.path.join(index_folder, first_char)
                    if not os.path.exists(dest_folder):
                        os.makedirs(dest_folder)
                    dest_file_path = os.path.join(dest_folder, filename)
                    with open(dest_file_path, 'a') as dest_file:
                        dest_file.write(password + '\n')
        # Dosyayı "Processed" klasörüne taşı
        shutil.move(file_path, os.path.join(processed_folder, filename))

print("İşlem tamamlandı.")

